package com.example.project_1;

import com.example.project_1.data.model.Journal;
import com.example.project_1.data.model.LoggedInUser;
import com.example.project_1.data.model.ResultItem;
import com.example.project_1.data.model.ResultTask;

import java.util.HashMap;
import java.util.List;
import java.util.Observable;

import retrofit2.Call;
import retrofit2.http.Body;
import retrofit2.http.DELETE;
import retrofit2.http.GET;
import retrofit2.http.HTTP;
import retrofit2.http.POST;
import retrofit2.http.PUT;
import retrofit2.http.Path;

public interface RetrofitInterface {
    //user
    @POST("/login")
    Call<LoggedInUser> executeLogin(@Body HashMap<String, String> map);

    @POST("/signup")
    Call<Void> executeSignup (@Body HashMap<String, String> map);

    @POST("/password")
    Call<Void> executeForgetPass (@Body HashMap<String, String> map);

    //task
    @POST("/task/create")
    Call<Void> executeCreateTask(@Body HashMap<String, String> map);

    @POST("/task/get_all_task")
    Call<List<ResultTask>> executeGetAllTask(@Body HashMap<String, String> map);

    @POST("/task/getOne")
    Call<ResultItem> executeGetTask(@Body HashMap<String, String> map);

    @PUT("/task/update")
    Call<List<ResultItem>> executeUpdateTask(@Body HashMap<String, String> map);

    @PUT("/task/finish")
    Call<Void> executeFinishTask(@Body HashMap<String, String> map);


//    @DELETE("/task/delete")
//    Call<Void> executeDeleteTask(@Body HashMap<String, String> map);

    @HTTP(method = "DELETE", path = "/task/delete", hasBody = true)
    Call<Void> executeDeleteTask(@Body HashMap<String, String> map);


    @POST("/post-journal")
    Call<Void> executePostJournal (@Body Journal journal);

//    @GET("/get-journal")
//    Call<JournalList> executeGetJournal ();

    @GET("/get-journal")
    Call<List<Journal>> executeGetJournal ();

    @POST("/get-journal-postId")
    Call<String> executeGetUserIdByTimeStamp (@Body HashMap<String,Long> timestamp);

    @POST("/delete-journal")
    Call<Void> executeDeleteJournal (@Body HashMap<String,Long> timestamp);

}
