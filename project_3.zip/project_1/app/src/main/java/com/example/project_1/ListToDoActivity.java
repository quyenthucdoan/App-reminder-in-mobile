package com.example.project_1;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import com.example.project_1.data.model.LoggedInUser;
import com.example.project_1.data.model.ResultItem;
import com.example.project_1.data.model.ResultTask;
import com.example.project_1.data.model.TaskAdapter;
import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.http.Body;

import static com.example.project_1.MyApplication.nguoidung;
import static com.example.project_1.MyApplication.retrofitInterface;

public class ListToDoActivity extends AppCompatActivity {

    TextView txtTrong;
    Button addTask;
    FloatingActionButton fab;

    ListView lvTask;
    List<ResultTask> taskList;
    TaskAdapter taskAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_list_to_do2);


        lvTask = findViewById(R.id.listViewTask);
        taskList = new ArrayList<>();

        loadData();
        for (int i = 0; i<taskList.size(); i++){
            Log.d("Quyen", taskList.get(i).getTitle());
        }



        txtTrong = findViewById(R.id.textviewTrong);

        fab = findViewById(R.id.fab);
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Log.d("Quyen", "day la FloatingActionButton: " + nguoidung.getName());
                Intent intent = new Intent (ListToDoActivity.this, SettingdateActivity.class);
                startActivity(intent);
            }
        });

//        fab.setFocusable(false);
//        fab.setFocusableInTouchMode(false);



        lvTask.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Log.d("Quyen", "setOnItemClickListener");
                Toast.makeText(ListToDoActivity.this, "setOnItemClickListener", Toast.LENGTH_SHORT).show();
                Intent intent = new Intent (ListToDoActivity.this, SettingdateActivity.class);
                intent.putExtra("task", taskList.get(position));
                startActivity(intent);
            }
        });
        lvTask.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {
            @Override
            public boolean onItemLongClick(AdapterView<?> parent, View view, int position, long id) {

                Log.d("Quyen", "setOnItemLongClickListener");
                Toast.makeText(ListToDoActivity.this, "setOnItemClickListener", Toast.LENGTH_SHORT).show();


                AlertDialog.Builder alert = new AlertDialog.Builder(ListToDoActivity.this);
                alert.setTitle("Delete entry");
                alert.setMessage("Are you sure you want to delete?");
                alert.setPositiveButton(android.R.string.yes, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {

                        XoaTask(taskList.get(position));

                        taskList.remove(position);
                        taskAdapter.notifyDataSetChanged();
                    }
                });
                alert.setNegativeButton(android.R.string.no, new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int which) {
                        // close dialog
                        dialog.cancel();
                    }
                });
                alert.show();

                return true;
            }
        });

    }

    private void XoaTask(ResultTask task) {
        HashMap<String, String> map = new HashMap<>();
        map.put("userid", nguoidung.getUserId());
        map.put("taskid", task.getId());
        Call<Void> call = retrofitInterface.executeDeleteTask(map);
        call.enqueue(new Callback<Void>() {
            @Override
            public void onResponse(Call<Void> call, Response<Void> response) {
                if(response.code() == 200){
                    Toast.makeText(ListToDoActivity.this, "Delete successful!", Toast.LENGTH_SHORT).show();
                }else{
                    Toast.makeText(ListToDoActivity.this, "Delete failure", Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onFailure(Call<Void> call, Throwable t) {
                Toast.makeText(ListToDoActivity.this, "Delete failure: " +t.getMessage(), Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void loadData() {
        HashMap<String, String> map = new HashMap<>();
        map.put("userid", nguoidung.getUserId());

        Log.d("Quyen", "map: " + map);
        Call<List<ResultTask>> call = retrofitInterface.executeGetAllTask(map);

        call.enqueue(new Callback<List<ResultTask>>() {
            @Override
            public void onResponse(Call<List<ResultTask>> call, Response<List<ResultTask>> response) {
                if(response.code() == 200){
                    List<ResultTask> results = response.body();
                    if(results.size() > 0){
                        txtTrong.setVisibility(View.INVISIBLE);

                        for(int i = 0; i < results.size(); i++){
                            taskList.add(results.get(i));
                            //Log.d("Quyen", taskList.get(i).getId());
                        }
                        taskAdapter = new TaskAdapter(ListToDoActivity.this, R.layout.list_view_bg, taskList);
                        lvTask.setAdapter(taskAdapter);

                    }else{
                        txtTrong.setVisibility(View.VISIBLE);
                    }

                }else{
                    Log.d("Quyen", "loi");
                }
            }

            @Override
            public void onFailure(Call<List<ResultTask>> call, Throwable t) {
                Log.d("Quyen", "loi: " + t.getMessage());
            }
        });


    }
}