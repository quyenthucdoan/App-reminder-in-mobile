package com.example.project_1;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.util.Log;

//dung trao doi du dien giũa các hệ thống
//dat thơi gian là 10h, khi 10h, no chạy vào cái class này
public class AlarmReceiver extends BroadcastReceiver {
    @Override
    public void onReceive(Context context, Intent intent) {
        Log.e("Quyen", "Toi dang onReceive");

        String key = intent.getExtras().getString("Bat nhac");
        int nhac = intent.getExtras().getInt("Nhac");

        Intent intentBatNhac = new Intent(context, Music.class);
        intentBatNhac.putExtra("Bat nhac", key);
        intentBatNhac.putExtra("Nhac", nhac);
        context.startService(intentBatNhac);

//        if(intent.getAction() == "ALARM"){
//            String key = intent.getExtras().getString("extra");
//            //String audio = intent.getExtras().getString("music");
//            //Uri audio = Uri.parse(intent.getExtras().getString("music"));
//            //Log.e("Quyen", "Toi dang onReceive, ban dang truyen key: " + key + " " + audio);
//
//            Intent myService = new Intent(context, Music.class);
//            myService.putExtra("extra", key);
//            //myService.putExtra("music", audio);
//            //myService.putExtra("music", audio.toString());
//            context.startService(myService);
//        }

    }
}
