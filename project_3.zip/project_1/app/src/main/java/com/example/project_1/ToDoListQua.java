package com.example.project_1;

import android.app.Application;

public class ToDoListQua extends Application {
}
