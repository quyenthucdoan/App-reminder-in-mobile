package com.example.project_1.data.model;

import java.util.Date;

public class ResultItem {
    private String title;
    private Boolean finished;

    public ResultItem(String title, Boolean finished) {
        this.title = title;
        this.finished = finished;
    }

    public ResultItem(String title) {
        this.title = title;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public Boolean getFinished() {
        return finished;
    }

    public void setFinished(Boolean finished) {
        this.finished = finished;
    }
}
