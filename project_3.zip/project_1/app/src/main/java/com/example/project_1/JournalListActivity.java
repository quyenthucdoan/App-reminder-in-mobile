package com.example.project_1;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.project_1.data.model.Journal;

import java.util.ArrayList;
import java.util.List;

import Adapter.JournalRecyclerAdapter;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;


public class JournalListActivity extends AppCompatActivity {
    private RetrofitInterface retrofitJournalInterface;
//    private Retrofit retrofit;
//    private String BASE_URL = "http://192.168.1.22:3000";

    private RecyclerView recyclerView;
    private List<Journal> journalList;
    private JournalRecyclerAdapter journalRecyclerAdapter;

    private String curentusername = MyApplication.nguoidung.getName();
    private String currentuserId = MyApplication.nguoidung.getUserId();




    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Log.e("Quyen", "onCreate trc");
        setContentView(R.layout.activity_journal_list);
        Log.e("Quyen", "onCreate sau");





//        retrofit = new Retrofit.Builder()
//                .baseUrl(BASE_URL)
//                .addConverterFactory(GsonConverterFactory.create())
//                .build();
        retrofitJournalInterface = MyApplication.retrofit.create(RetrofitInterface.class);
        Intent intent = getIntent();
        curentusername = intent.getStringExtra("username");
        currentuserId = intent.getStringExtra("userId");
        journalList = new ArrayList<>();
        recyclerView = findViewById(R.id.recycleView);
//        recyclerView.setHasFixedSize(true);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));



        Call<List<Journal>> call = retrofitJournalInterface.executeGetJournal();
//        call.enqueue(new Callback<JournalList>() {
//            @Override
//            public void onResponse(Call<JournalList> call, Response<JournalList> response) {
//                Log.d("Journal List", "onResponse: " + response.body().getJournalList());
//                for(Journal journal : response.body().getJournalList()){
//                    Log.d("Journal List index", "onResponse: " + journal);
//                }
//
//            }
//
//            @Override
//            public void onFailure(Call<JournalList> call, Throwable t) {
//                Toast.makeText(JournalListActivity.this, t.getMessage(),Toast.LENGTH_LONG);
//            }
//        });
        call.enqueue(new Callback<List<Journal>>() {
            @Override
            public void onResponse(Call<List<Journal>> call, Response<List<Journal>> response) {
                //assert response.body() != null;
                if(response.body().size() == 0 ){
                    Log.e("Quyen", "bị null");
                    Toast.makeText(JournalListActivity.this, "chua có hoat dong", Toast.LENGTH_SHORT).show();
                }else{
                    Log.e("Quyen", "khong null");
                    journalList.addAll(response.body());
                    journalRecyclerAdapter = new JournalRecyclerAdapter(JournalListActivity.this,journalList);
                    Log.d("Journallist Size", "onResponse: " +journalRecyclerAdapter.getItemCount());
                    recyclerView.setAdapter(journalRecyclerAdapter);
                    journalRecyclerAdapter.notifyDataSetChanged();
                }

            }

            @Override
            public void onFailure(Call<List<Journal>> call, Throwable t) {
                Log.e("Quyen", t.getMessage());
                Toast.makeText(JournalListActivity.this,t.getMessage(),Toast.LENGTH_LONG);
            }
        });


    }



    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu,menu);
        return super.onCreateOptionsMenu(menu);
    }

    @SuppressLint("NonConstantResourceId")
    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        switch(item.getItemId()){
            case R.id.action_add:
                Intent intent = new Intent(JournalListActivity.this,PostJournalActivity.class);
                intent.putExtra("username", curentusername);
                intent.putExtra("userId", currentuserId);
                startActivity(intent);
                break;

            case R.id.action_signout:
                startActivity(new Intent(JournalListActivity.this, MainActivity.class));
                break;
        }
        return super.onOptionsItemSelected(item);
    }

    @Override
    protected void onStart() {
        super.onStart();
        Log.e("Quyen", "onStart");

    }
}