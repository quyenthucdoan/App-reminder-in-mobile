package com.example.project_1;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.example.project_1.ui.login.LoginActivity;

import java.util.HashMap;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

import static com.example.project_1.MyApplication.retrofitInterface;

public class RegisterActivity extends AppCompatActivity {

    Button signupButton, logininButton;
    EditText edtName, edtEmail, edtPassword, edtConfirm;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);

        signupButton = (Button) findViewById(R.id.login2_2);
        logininButton = (Button) findViewById(R.id.login_2);
        edtName = findViewById(R.id.username);
        edtEmail = findViewById(R.id.email);
        edtPassword = findViewById(R.id.password);
        edtConfirm = findViewById(R.id.confirm);

        signupButton.setEnabled(true);
        logininButton.setEnabled(true);

        signupButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                String pass = edtPassword.getText().toString();
                String confirm = edtConfirm.getText().toString();
                if(!pass.equals(confirm)){
                    Toast.makeText(RegisterActivity.this, "Confirm is not equal to password", Toast.LENGTH_SHORT).show();
                    return;
                }

                HashMap<String, String> map = new HashMap<>();
                map.put("name", edtName.getText().toString());
                map.put("email", edtEmail.getText().toString());
                map.put("password", pass);
                Log.d("Quyen", "ham dang ki1");
                Call<Void> call = retrofitInterface.executeSignup(map);
                Log.d("Quyen", "ham dang ki2");
                call.enqueue(new Callback<Void>() {
                    @Override
                    public void onResponse(Call<Void> call, Response<Void> response) {
                        if (response.code() == 200) {
                            Log.d("Quyen", "dang ki_ response.code = 200");
                            Toast.makeText(RegisterActivity.this, "Sign up successfully", Toast.LENGTH_SHORT).show();
                            Intent intent = new Intent(RegisterActivity.this, LoginActivity.class);
                            startActivity(intent);
                        } else {
                            if(response.code() == 400){
                                Log.d("Quyen", "Dnag ki _ 400");
                            }
                            Toast.makeText(RegisterActivity.this, "Already registered", Toast.LENGTH_SHORT).show();
                        }
                    }

                    @Override
                    public void onFailure(Call<Void> call, Throwable t) {
                        Toast.makeText(RegisterActivity.this, t.getMessage(), Toast.LENGTH_SHORT).show();
                    }
                });
            }
        });

        logininButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(RegisterActivity.this, LoginActivity.class);
                startActivity(intent);
            }
        });
    }
}