package com.example.project_1.ui.login;

import android.app.Activity;

import androidx.lifecycle.Observer;
import androidx.lifecycle.ViewModelProvider;

import android.app.Dialog;
import android.content.Intent;
import android.os.Bundle;

import androidx.annotation.Nullable;
import androidx.annotation.StringRes;
import androidx.appcompat.app.AppCompatActivity;

import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.KeyEvent;
import android.view.View;
import android.view.inputmethod.EditorInfo;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import com.example.project_1.MainActivity;
import com.example.project_1.MyApplication;
import com.example.project_1.R;
import com.example.project_1.RegisterActivity;
import com.example.project_1.SettingdateActivity;
import com.example.project_1.data.model.LoggedInUser;

import java.util.HashMap;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.http.Body;

import static com.example.project_1.MyApplication.retrofitInterface;
import static com.example.project_1.MyApplication.nguoidung;

public class LoginActivity extends AppCompatActivity {



    private LoginViewModel loginViewModel;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        //View
        loginViewModel = new ViewModelProvider(this, new LoginViewModelFactory())
                .get(LoginViewModel.class);

        final EditText usernameEditText = findViewById(R.id.username);
        final EditText passwordEditText = findViewById(R.id.password);
        final Button loginButton = findViewById(R.id.login_1);
        final Button signupButton = findViewById(R.id.login2_1);
        final Button btnForgetPass = findViewById(R.id.buttonForgetPassword);
        final ProgressBar loadingProgressBar = findViewById(R.id.loading);
        loginButton.setEnabled(true);
        signupButton.setEnabled(true);
        loginViewModel.getLoginFormState().observe(this, new Observer<LoginFormState>() {
            @Override
            public void onChanged(@Nullable LoginFormState loginFormState) {
                if (loginFormState == null) {
                    return;
                }
                loginButton.setEnabled(true);
                loginButton.setEnabled(loginFormState.isDataValid());
                if (loginFormState.getUsernameError() != null) {
                    usernameEditText.setError(getString(loginFormState.getUsernameError()));
                }
                if (loginFormState.getPasswordError() != null) {
                    passwordEditText.setError(getString(loginFormState.getPasswordError()));
                }
            }
        });
        loginViewModel.getLoginResult().observe(this, new Observer<LoginResult>() {
            @Override
            public void onChanged(@Nullable LoginResult loginResult) {
                if (loginResult == null) {
                    return;
                }
                loadingProgressBar.setVisibility(View.GONE);
                if (loginResult.getError() != null) {
                    showLoginFailed(loginResult.getError());
                }
                if (loginResult.getSuccess() != null) {
                    updateUiWithUser(loginResult.getSuccess());
                }
                setResult(Activity.RESULT_OK);

                //Complete and destroy login activity once successful
                finish();
            }
        });

        TextWatcher afterTextChangedListener = new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
                // ignore
            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                // ignore
            }

            @Override
            public void afterTextChanged(Editable s) {
//                loginViewModel.loginDataChanged(usernameEditText.getText().toString(),
//                        passwordEditText.getText().toString());
            }
        };
        usernameEditText.addTextChangedListener(afterTextChangedListener);
        passwordEditText.addTextChangedListener(afterTextChangedListener);
        passwordEditText.setOnEditorActionListener(new TextView.OnEditorActionListener() {
            @Override
            public boolean onEditorAction(TextView v, int actionId, KeyEvent event) {
                if (actionId == EditorInfo.IME_ACTION_DONE) {
//                    loginViewModel.login(usernameEditText.getText().toString(),
//                            passwordEditText.getText().toString());
                }
                return false;
            }
        });
        loginButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Log.e("Quyen", "click button login ơ activity lotgin");
                loadingProgressBar.setVisibility(View.VISIBLE);
//                loginViewModel.login(usernameEditText.getText().toString(),
//                        passwordEditText.getText().toString());
                String email = usernameEditText.getText().toString();
                String password = passwordEditText.getText().toString();

                HashMap<String, String> map = new HashMap<>();
                map.put("email", email);
                map.put("password", password);

                Log.d("Quyen", email + " " + password);
                Call<LoggedInUser> call = retrofitInterface.executeLogin(map);

                call.enqueue(new Callback<LoggedInUser>() {
                    @Override
                    public void onResponse(Call<LoggedInUser> call, Response<LoggedInUser> response) {
                        if (response.code() == 200) {
                            Log.d("Quyen", "200");
                            LoggedInUser result = response.body();
                            Log.d("Quyen", "result login: " + result.getUserId() + " " + result.getName());
                            Toast.makeText(LoginActivity.this, "Login successful" + result.getUserId() + " " + result.getName(), Toast.LENGTH_SHORT).show();

                            nguoidung = result;

                            Intent intent = new Intent(LoginActivity.this, MainActivity.class);
                            intent.putExtra("username",response.body().getName());
                            intent.putExtra("userId",response.body().getUserId());
                            LoginActivity.this.startActivity(intent);
                        } else if (response.code() == 404) {
                            Log.d("Quyen", "404");
                            Toast.makeText(LoginActivity.this, "Account not exist", Toast.LENGTH_SHORT).show();
                        }
                    }
                    @Override
                    public void onFailure(Call<LoggedInUser> call, Throwable t) {
                        Log.d("Quyen", t.getMessage());
                        Toast.makeText(LoginActivity.this, "hello " + t.getMessage(), Toast.LENGTH_SHORT).show();
                    }
                });


            }
        });


            signupButton.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Log.e("Quyen", "click button dang ki ơ activity lotgin");
                    Intent intent = new Intent(LoginActivity.this, RegisterActivity.class);
                    LoginActivity.this.startActivity(intent);
                }
            });

            btnForgetPass.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    final Dialog dialog = new Dialog(LoginActivity.this);
                    dialog.setContentView(R.layout.custom_dialog_forgte_password);
                    Button dialogButton = (Button) dialog.findViewById(R.id.dialogButtonOK);
                    TextView btncancel = dialog.findViewById(R.id.textViewCancel);
                    EditText edtEmail = dialog.findViewById(R.id.edittextEmail);

                    // if button is clicked, close the custom dialog
                    dialogButton.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            HashMap<String, String> map = new HashMap<>();
                            map.put("email", edtEmail.getText().toString());
                            Call<Void> call = retrofitInterface.executeForgetPass (map);
                            call.enqueue(new Callback<Void>() {
                                @Override
                                public void onResponse(Call<Void> call, Response<Void> response) {
                                    if(response.code() == 200){
                                        dialog.dismiss();
                                        Toast.makeText(LoginActivity.this, "Chang password successful", Toast.LENGTH_SHORT).show();
                                    }
                                }

                                @Override
                                public void onFailure(Call<Void> call, Throwable t) {

                                }
                            });
                        }
                    });
                    dialog.show();

                    btncancel.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            dialog.dismiss();
                            Toast.makeText(getApplicationContext(),"Dismissed..!!",Toast.LENGTH_SHORT).show();
                        }
                    });
                }
            });


    }

    private void updateUiWithUser(LoggedInUserView model) {
        String welcome = getString(R.string.welcome) + model.getDisplayName();
        // TODO : initiate successful logged in experience
        Toast.makeText(getApplicationContext(), welcome, Toast.LENGTH_LONG).show();
    }

    private void showLoginFailed(@StringRes Integer errorString) {
        Toast.makeText(getApplicationContext(), errorString, Toast.LENGTH_SHORT).show();
    }


}