package com.example.project_1;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ImageButton;
import android.widget.ImageView;

import static com.example.project_1.MyApplication.nguoidung;

public class MainActivity extends AppCompatActivity {
    ImageButton logout;
    ImageButton help;
    ImageButton forum;

    ImageView imgToDoList, imgForum, imgTimer, imgProfile;

    private String currentUsername;
    private String currentUserId;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        //Log.d("Quyen", "MainActivity, có ng dung: " + nguoidung.getName());
        Anhxa();
        Intent intent = getIntent();
        currentUsername = intent.getStringExtra("username");
        currentUserId = intent.getStringExtra("userId");

//        Intent in = getIntent();
//        String string = in.getStringExtra("Notice!");
        forum.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent1 = new Intent(MainActivity.this,PostJournalActivity.class);
//                intent1.putExtra("username",currentUsername);
//                intent1.putExtra("userId", currentUserId);
                startActivity(intent1);
            }
        });
        logout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                AlertDialog.Builder builder;
                builder = new AlertDialog.Builder (MainActivity.this);
                builder.setTitle("Wait my bae...!").
                        setMessage("You sure, that you want to leave me...?");
                builder.setPositiveButton("Be right backkk!",
                        new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog, int id) {
                                Intent i = new Intent(getApplicationContext(),
                                        MainActivity.class);
                                startActivity(i);
                            }
                        });
                builder.setNegativeButton("No no",
                        new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog, int id) {
                                dialog.cancel();
                            }
                        });
                AlertDialog alert11 = builder.create();
                alert11.show();
            }
        });
        help.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Log.d("Quyen", nguoidung.getUserId());

                AlertDialog.Builder builder;
                builder = new AlertDialog.Builder (MainActivity.this);
                builder.setIcon(R.drawable.support);
                builder.setTitle("May QUA help you something....").
                        setMessage("Dear my love," +
                                "This is the application that QUA has created to help you have comfortable learning and working moments with your loved ones.\n" +
                                "So how to use QUA:\n"+
                                "1. Create a PROJECT for you\n"+
                                "2. Create a LISTTODO in this PROJECT\n"+
                                "3. Set up DATE&TIME for this work\n"+
                                "4. Intive your friend and enjoy with chat box or social media\n"+
                                "If you find it difficult to understand something, please contact us via email: QUA.support@email.com\n"+
                                "Thanks for your gold time in here <3!\n");
                builder.setPositiveButton("Understand",
                        new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog, int id) {
                                Intent i = new Intent(getApplicationContext(),
                                        MainActivity.class);
                                startActivity(i);
                            }
                        });
                AlertDialog alert11 = builder.create();
                alert11.show();
            }
        });

        imgToDoList.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, ListToDoActivity.class );
                startActivity(intent);
            }
        });
        imgProfile.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, ProfileActivity.class );
                startActivity(intent);
            }
        });
        imgTimer.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, CountdownActivity.class );
                startActivity(intent);
            }
        });

    }

    private void Anhxa() {
        logout = (ImageButton) findViewById(R.id.button_logout2);
        help = (ImageButton) findViewById(R.id.button_help2);
        imgToDoList = findViewById(R.id.imageView8);
        imgForum = findViewById(R.id.imageView9);
        imgTimer = findViewById(R.id.imageView5);
        imgProfile = findViewById(R.id.imageView7);
        forum = (ImageButton) findViewById(R.id.imageView9);

    }
}