package com.example.project_1.data.model;

import android.content.Context;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Typeface;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.core.content.ContextCompat;

import com.example.project_1.ListToDoActivity;
import com.example.project_1.R;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.http.Body;

import static com.example.project_1.MyApplication.nguoidung;
import static com.example.project_1.MyApplication.retrofitInterface;
import static com.example.project_1.R.color.whiteTextColor;

public class TaskAdapter extends BaseAdapter {
    private Context context;
    private int Layout;
    private List<ResultTask> taskList;

    public TaskAdapter(Context context, int layout, List<ResultTask> taskList) {
        this.context = context;
        this.Layout = layout;
        this.taskList = taskList;
    }

    @Override
    public int getCount() {
        return taskList.size();
    }

    @Override
    public Object getItem(int position) {
        return null;
    }

    @Override
    public long getItemId(int position) {
        return 0;
    }

    private class ViewHolder{
        //ImageView imgHinh;
        TextView txtTitle, txtDue, txtReminder;
        CheckBox cbFinish;
        ImageView imgBell;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {

        Date due_date = null;
        String  due_date_str;
        String patternDue = "dd MMM";
        SimpleDateFormat dateFormatDue = new SimpleDateFormat(patternDue);

        Date reminder = null;
        String  reminder_str;
        String patternReminder = "dd MMM HH:mm";
        SimpleDateFormat dateFormatReminder = new SimpleDateFormat(patternReminder);

        ViewHolder viewHolder;
        if(convertView == null){
            LayoutInflater inflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            convertView = inflater.inflate(Layout, null);
            viewHolder = new ViewHolder();
            //Anh xa View
            viewHolder.txtTitle = convertView.findViewById(R.id.textviewtitle);
            viewHolder.txtDue = (TextView) convertView.findViewById(R.id.textViewDueDate);
            viewHolder.txtReminder = (TextView) convertView.findViewById(R.id.textViewReminder);
            viewHolder.cbFinish = convertView.findViewById(R.id.checkBoxFinish);
            viewHolder.imgBell = convertView.findViewById(R.id.imageViewIC1);
            convertView.setTag(viewHolder);
        }else{
            viewHolder = (ViewHolder) convertView.getTag();
        }
        //Gan gia tri
        ResultTask tasks = taskList.get(position);

        viewHolder.txtTitle.setText(tasks.getTitle());

        try
        {
            due_date = tasks.getDue_date();
            due_date_str = dateFormatDue.format(due_date);
            //Log.d("Quyen", "taskadpter due " + due_date_str);
            viewHolder.txtDue.setText(due_date_str);
        }
        catch(Exception e)
        {
            e.printStackTrace();
            viewHolder.txtDue.setText("Khong co");
        }

        try
        {
            reminder = tasks.getTimeReminder();
            reminder_str = dateFormatReminder.format(reminder);
            Log.d("Quyen", "taskadpter, reminder " + reminder_str);
            viewHolder.txtReminder.setText(reminder_str);
        }
        catch(Exception e)
        {
            e.printStackTrace();
            viewHolder.txtReminder.setText("Khong co");
        }

        if(tasks.getFinished() == Boolean.TRUE){
            viewHolder.cbFinish.setChecked(true);
            viewHolder.txtTitle.setPaintFlags(viewHolder.txtTitle.getPaintFlags() | Paint.STRIKE_THRU_TEXT_FLAG);
            viewHolder.txtTitle.setTypeface(viewHolder.txtTitle.getTypeface(), Typeface.ITALIC);
            viewHolder.txtTitle.setTextColor(context.getResources().getColor(R.color.teal2));
            viewHolder.txtDue.setTextColor(Color.parseColor("#7d8992"));
            viewHolder.txtReminder.setTextColor(Color.parseColor("#7d8992"));
            viewHolder.imgBell.setImageResource(R.drawable.bell2);
        }else{
            viewHolder.cbFinish.setChecked(false);
            viewHolder.txtTitle.setTypeface(viewHolder.txtTitle.getTypeface(), Typeface.BOLD);
            viewHolder.txtTitle.setPaintFlags(viewHolder.txtTitle.getPaintFlags() & (~ Paint.STRIKE_THRU_TEXT_FLAG));
            viewHolder.txtTitle.setTextColor(context.getResources().getColor(R.color.teal_200));
            viewHolder.txtDue.setTextColor(context.getResources().getColor(whiteTextColor));
            viewHolder.txtReminder.setTextColor(context.getResources().getColor(whiteTextColor));
            viewHolder.imgBell.setImageResource(R.drawable.bell4);
        }



        viewHolder.cbFinish.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                HashMap<String, String> map = new HashMap<>();
                map.put("userid", nguoidung.getUserId());
                map.put("taskid", tasks.getId());
                map.put("finished", Boolean.toString(isChecked));
                Call<Void> call = retrofitInterface.executeFinishTask(map);
                call.enqueue(new Callback<Void>() {
                    @Override
                    public void onResponse(Call<Void> call, Response<Void> response) {
                        if(response.code() == 200){
                            if(isChecked){
                                tasks.setFinished(true);
                                viewHolder.txtTitle.setPaintFlags(viewHolder.txtTitle.getPaintFlags() | Paint.STRIKE_THRU_TEXT_FLAG);
                                viewHolder.txtTitle.setTypeface(viewHolder.txtTitle.getTypeface(), Typeface.ITALIC);
                                viewHolder.txtTitle.setTextColor(context.getResources().getColor(R.color.teal2));
                                viewHolder.txtDue.setTextColor(Color.parseColor("#7d8992"));
                                viewHolder.txtReminder.setTextColor(Color.parseColor("#7d8992"));
                                viewHolder.imgBell.setImageResource(R.drawable.bell2);

                            }else{
                                tasks.setFinished(false);
                                viewHolder.txtTitle.setTypeface(viewHolder.txtTitle.getTypeface(), Typeface.BOLD);
                                viewHolder.txtTitle.setPaintFlags(viewHolder.txtTitle.getPaintFlags() & (~ Paint.STRIKE_THRU_TEXT_FLAG));
                                viewHolder.txtTitle.setTextColor(context.getResources().getColor(R.color.teal_200));
                                viewHolder.txtDue.setTextColor(context.getResources().getColor(whiteTextColor));
                                viewHolder.txtReminder.setTextColor(context.getResources().getColor(whiteTextColor));
                                viewHolder.imgBell.setImageResource(R.drawable.bell4);
                            }
                        }else{
                            Log.d("Quyen", "Loi");
                        }
                    }

                    @Override
                    public void onFailure(Call<Void> call, Throwable t) {
                        Log.d("Quyen", t.getMessage());
                        Toast.makeText(context, "Error: " +t.getMessage(), Toast.LENGTH_SHORT).show();
                    }
                });
            }
        });

        return convertView;
    }

}
