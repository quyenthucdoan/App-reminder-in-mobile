package com.example.project_1;

import android.app.Application;

import com.example.project_1.data.model.LoggedInUser;

import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

public class MyApplication extends Application {

    public static String BASE_URL = "http://192.168.1.9:3000"; // chỉnh lại theo wifi cua m
    public static Retrofit retrofit = new Retrofit.Builder()
            .baseUrl(BASE_URL)
            .addConverterFactory(GsonConverterFactory.create())
            .build();
    public static RetrofitInterface retrofitInterface = retrofit.create(RetrofitInterface.class);
    public static LoggedInUser nguoidung;
}
