package com.example.project_1;

import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.TextView;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import com.example.project_1.data.model.Journal;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

public class PostJournalActivity extends AppCompatActivity implements View.OnClickListener {
    private static final int GALLERY_CODE = 1;
    private ImageView addPhotoBut;
    private EditText titleEditText;
    private EditText thoughtsEditText;
    private TextView currentUserTextView;
    private ImageView imageView;
    private String currentUserName;
    private String currentUserId;
    ImageView camera;

    private Button saveButton;

    private ProgressBar progressBar;
    private Uri imageUri;

//    private RetrofitInterface retrofitJournalInterface;
//    private Retrofit retrofit;
//    private String BASE_URL = "http://192.168.1.22:3000";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_post_journal);

//        Myretrofit = new Retrofit.Builder()
//                .baseUrl(BASE_URL)
//                .addConverterFactory(GsonConverterFactory.create())
//                .build();

        //retrofitJournalInterface = MyApplication.retrofitInterface.create(RetrofitInterface.class);
        addPhotoBut = findViewById(R.id.postCameraButton);
        titleEditText = findViewById(R.id.post_title_et);
        thoughtsEditText = findViewById(R.id.post_description_et);
        currentUserTextView = findViewById(R.id.post_username_textview);
        progressBar = findViewById(R.id.post_progressBar);
        saveButton = findViewById(R.id.post_save_journal_button);
        saveButton.setOnClickListener(this);
        addPhotoBut.setOnClickListener(this);
        imageView = findViewById(R.id.post_imageView);

        addPhotoBut.setVisibility(View.VISIBLE);
        progressBar.setVisibility(View.INVISIBLE);

        Intent intent = getIntent();
        currentUserId = intent.getStringExtra("userId");
        Log.d("USerId", "onCreate: " + currentUserId);
        currentUserName = intent.getStringExtra("username");

        currentUserTextView.setText(MyApplication.nguoidung.getName());


    }

    @Override
    public void onClick(View v) {
        switch(v.getId()){
            case R.id.post_save_journal_button:
                saveJournal();
                break;
            case R.id.postCameraButton:
                //get image from gallery
                Intent galleryIntent = new Intent(Intent.ACTION_GET_CONTENT);
                galleryIntent.setType("image/*");
//                handleIncomingData(galleryIntent);
                try {
                    startActivityForResult(galleryIntent,GALLERY_CODE);
                } catch (ActivityNotFoundException activityNotFound) {
                    Log.d("Hello", "onClick: Again!");
                }

                break;
        }
    }


    private void saveJournal() {
        String title = titleEditText.getText().toString().trim();
        String thoughts = thoughtsEditText.getText().toString().trim();
        Log.d("Quyen", "saveJournal: " + imageUri.toString());
        progressBar.setVisibility(View.VISIBLE);
        if(!TextUtils.isEmpty(title) && !TextUtils.isEmpty(thoughts)){
            Journal journal = new Journal();
            journal.setUsername(MyApplication.nguoidung.getName());
            journal.setImageUrl(imageUri.toString());
            journal.setThoughts(thoughts);
            journal.setTitle(title);
            journal.setTimeAdded(System.currentTimeMillis()/1000);
            journal.setUserId(MyApplication.nguoidung.getUserId());
            Call<Void> call = MyApplication.retrofitInterface.executePostJournal(journal);
//            Intent intent = new Intent(PostJournalActivity.this,JournalListActivity.class);
//            intent.putExtra("username", currentUserName);
//            intent.putExtra("userId", currentUserId);
//            startActivity(intent);
            call.enqueue(new Callback<Void>() {
                @Override
                public void onResponse(Call<Void> call, Response<Void> response) {
                   if(response.code() == 200){
                       Log.d("Quyen", "onResponse: " + response.body());
                       Intent intent = new Intent(PostJournalActivity.this,JournalListActivity.class);
                       intent.putExtra("username", currentUserName);
                       intent.putExtra("userId", currentUserId);
                       startActivity(intent);
                   }
                }

                @Override
                public void onFailure(Call<Void> call, Throwable t) {
                    Log.d("Quyen", "onFailure: " + t.getMessage());
                }
            });
            startActivity(new Intent(PostJournalActivity.this,JournalListActivity.class));

        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if(resultCode == RESULT_OK && requestCode == GALLERY_CODE){
            if (data != null) {
                imageUri = data.getData(); // we have the actual path to the image
                imageView.setImageURI(imageUri); //show image
            } else {
                Log.d("MainActivity", "onActivityResult: Failded");
            }
        }
    }
}