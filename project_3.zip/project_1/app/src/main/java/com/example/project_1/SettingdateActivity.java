package com.example.project_1;

import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.NotificationCompat;
import androidx.core.app.NotificationManagerCompat;

import android.app.AlarmManager;
import android.app.DatePickerDialog;
import android.app.Notification;
import android.app.PendingIntent;
import android.app.TimePickerDialog;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;


import android.os.Handler;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.TimePicker;
import android.widget.Toast;

import com.example.project_1.data.model.ResultTask;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;

import java.util.logging.LogRecord;


import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

import static com.example.project_1.MyApplication.retrofitInterface;

public class SettingdateActivity extends AppCompatActivity {

    //thanh phan
    EditText edtTitle, edtSummary, edtDueDate, edtDateReminder, edtTimeReminder;
    Button btn_sound_1, btn_sound_2, btn_sound_3, btn_sound_4;
    Button btnChooseTime, btnChooseDate;
    ImageButton btnDone;
    Button mDisplayDateTime;

    //them
    private SoundManager mSoundManager;
    Calendar mDateAndTime = Calendar.getInstance();
    MyApplication myApplication;

    int chooseSound = 1; //chon bai
    //String userid = myApplication.nguoidung.getUserId();

    //dinh dang
    SimpleDateFormat dingDangNgay = new SimpleDateFormat("dd/MM/yyyy");
    SimpleDateFormat dinhDangGio = new SimpleDateFormat("HH:mm:ss");

    Calendar calendarD = Calendar.getInstance();
    int ngayD = calendarD.get(Calendar.DATE);
    int thangD = calendarD.get(Calendar.MONTH);
    int namD = calendarD.get(Calendar.YEAR);
    int gioD = calendarD.get(Calendar.HOUR_OF_DAY);
    int phutD = calendarD.get(Calendar.MINUTE);

    Calendar calendarR = Calendar.getInstance();
    int ngayR = calendarD.get(Calendar.DATE);
    int thangR = calendarD.get(Calendar.MONTH);
    int namR = calendarD.get(Calendar.YEAR);
    int gioR = calendarD.get(Calendar.HOUR_OF_DAY);
    int phutR = calendarD.get(Calendar.MINUTE);

    //Bao thuc
    AlarmManager alarmManager;
    Intent intentBaoThuc;
    PendingIntent pendingIntentBaoThuc;
    public Uri audio = null;
    int notificationId = 1;
    int REQ_CODE_PICK_SOUNDFILE = 1;
    NotificationManagerCompat notificationManagerCompat;

    //wait
    Handler handler;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_ltd);

        AnhXa();
        playMusic();


        calendarR.setTimeInMillis(System.currentTimeMillis());

        handler = new Handler();

        //Tao AlarManager//cho phep truy cap va he thong bao dong cua he thong//dung de bao thuc
        alarmManager = (AlarmManager) getSystemService(ALARM_SERVICE);
        intentBaoThuc = new Intent(SettingdateActivity.this, AlarmReceiver.class);

        //update task, nếu update task, thì gan gia tri vao edittext
        Intent intentUpdateTask = getIntent();
        ResultTask resultTask = (ResultTask) intentUpdateTask.getSerializableExtra("task");
        if(resultTask != null){
            edtTitle.setText(resultTask.getTitle());
            edtSummary.setText(resultTask.getSummary());



            Date d = resultTask.getDue_date();
            Date r =  resultTask.getTimeReminder();

            if(d != null){
                edtDueDate.setText(dingDangNgay.format(d));
            }
            if(r != null){
                edtDateReminder.setText(dingDangNgay.format(r));
                edtTimeReminder.setText(dinhDangGio.format(r));
            }

        }

        edtDueDate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ChonNgayDueDate();
            }
        });

        btnChooseDate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ChonNgayReminder();
            }
        });

        btnChooseTime.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ChonGio();
            }
        });

        btn_sound_1.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                mSoundManager.playSound(1);
                chooseSound = 1;
            }
        });

        btn_sound_2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mSoundManager.playSound(2);
                chooseSound = 2;
            }
        });

        btn_sound_3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mSoundManager.playSound(2);
                chooseSound = 3;
            }
        });

        btn_sound_4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mSoundManager.playSound(2);
                chooseSound = 4;
            }
        });
        Log.d("Quyen", "chon nhac:" + chooseSound);

        btnDone.setOnClickListener(new View.OnClickListener() {
            @RequiresApi(api = Build.VERSION_CODES.M)
            @Override
            public void onClick(View v) {
                Log.d("Quyen", "click done: ");

                if (edtTitle.getText().toString().equals("")) {
                    Toast.makeText(SettingdateActivity.this, "Adding title is required", Toast.LENGTH_SHORT).show();
                    quayVe();
                } else {
                    TaoTask();
                }
            }
        });




        this.notificationManagerCompat = NotificationManagerCompat.from(this);
    }

    private void TaoTask() {
        HashMap<String, String> map = new HashMap<>();
        map.put("userid", MyApplication.nguoidung.getUserId());

        map.put("title", edtTitle.getText().toString());
        map.put("summary", edtSummary.getText().toString());

        map.put("yearD", Integer.toString(namD));
        map.put("monthD", Integer.toString(thangD));
        map.put("dayD", Integer.toString(ngayD));
        map.put("hourD", Integer.toString(gioD));
        map.put("minuteD", Integer.toString(phutD));

        map.put("yearR", Integer.toString(namR));
        map.put("monthR", Integer.toString(thangR));
        map.put("dayR", Integer.toString(ngayR));
        map.put("hourR", Integer.toString(gioR));
        map.put("minuteR", Integer.toString(phutR));

        map.put("sound", Integer.toString(chooseSound));

        Log.d("Quyen", "click:=" + map);

        Call<Void> call = retrofitInterface.executeCreateTask(map);
        call.enqueue(new Callback<Void>() {
            @RequiresApi(api = Build.VERSION_CODES.M)
            @Override
            public void onResponse(Call<Void> call, Response<Void> response) {
                if (response.code() == 201) {
                    Log.d("Quyen", "tao_ response.code = 200");
                    Toast.makeText(SettingdateActivity.this, "Add successfully", Toast.LENGTH_SHORT).show();

                    baoThuc();


                    //alarmManager.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, calendarR.getTimeInMillis(), pendingIntent);
                    //sendOnChannel1(d, M, y, h, m);

//                    Intent mintent = new Intent();//Intent.ACTION_PICK,android.provider.MediaStore.Audio.Media.EXTERNAL_CONTENT_URI);
//                    mintent.setAction(Intent.ACTION_GET_CONTENT);
//                    mintent.setType("audio/*");

                    //this.notificationManagerCompat = NotificationManagerCompat.from(this);

                    //Intent notifyIntent = new Intent(this, MainActivity.class);
//                    notifyIntent.setAction("Notification");
//                    notifyIntent.putExtra("com.uit.alarm.notifyId", notificationId);
//                    PendingIntent notifyPendingIntent = PendingIntent.getBroadcast(this, 123, notifyIntent, 0);




                    quayVe();
                } else {
                    Log.d("Quyen", "Dnag ki _ 400");
                    Toast.makeText(SettingdateActivity.this, "Add failure", Toast.LENGTH_SHORT).show();
                    quayVe();
                }
            }
            @Override
            public void onFailure(Call<Void> call, Throwable t) {

            }
        });
    }

    @RequiresApi(api = Build.VERSION_CODES.M)
    private void baoThuc() {
        Calendar cal=Calendar.getInstance();
        cal.set(Calendar.MONTH,thangR);
        cal.set(Calendar.YEAR,namR);
        cal.set(Calendar.DAY_OF_MONTH,ngayR);
        cal.set(Calendar.HOUR_OF_DAY,gioR);
        cal.set(Calendar.MINUTE,phutR);

        intentBaoThuc.putExtra("Bat nhac", "on");
        intentBaoThuc.putExtra("Nhac", chooseSound);
        pendingIntentBaoThuc = PendingIntent.getBroadcast(
                SettingdateActivity.this, 0, intentBaoThuc , PendingIntent.FLAG_UPDATE_CURRENT);
        alarmManager.set(AlarmManager.RTC_WAKEUP,cal.getTimeInMillis(), pendingIntentBaoThuc);




        handler.postDelayed(new Runnable() {
            public void run() {
                Log.d("Quyen", "ham cho");
                sendOnChannel1();
            }
        },cal.getTimeInMillis() - System.currentTimeMillis() );


    }


    private void quayVe() {
        Intent intent = new Intent(SettingdateActivity.this, ListToDoActivity.class);
        startActivity(intent);
    }

    private void playMusic() {

    }


    private void ChonNgayDueDate(){
        Calendar calendar = Calendar.getInstance();
        int ngay = calendar.get(Calendar.DATE);
        int thang = calendar.get(Calendar.MONTH);
        int nam = calendar.get(Calendar.YEAR);
        DatePickerDialog datePickerDialog = new DatePickerDialog(this, new DatePickerDialog.OnDateSetListener() {
            @Override
            public void onDateSet(DatePicker view, int year, int month, int dayOfMonth) {
                calendar.set(year, month, dayOfMonth);
                edtDueDate.setText(dingDangNgay.format(calendar.getTime()));
                namD = year;
                thangD = month;
                ngayD = dayOfMonth;
            }
        }, nam, thang, ngay);
        datePickerDialog.show();

    }
    private void ChonNgayReminder(){
        Calendar calendar = Calendar.getInstance();
        int ngay = calendar.get(Calendar.DATE);
        int thang = calendar.get(Calendar.MONTH);
        int nam = calendar.get(Calendar.YEAR);
        DatePickerDialog datePickerDialog = new DatePickerDialog(this, new DatePickerDialog.OnDateSetListener() {
            @Override
            public void onDateSet(DatePicker view, int year, int month, int dayOfMonth) {
                calendar.set(year, month, dayOfMonth);
                edtDateReminder.setText(dingDangNgay.format(calendar.getTime()));
                namR = year;
                thangR = month;
                ngayR = dayOfMonth;
            }
        }, nam, thang, ngay);
        datePickerDialog.show();
    }
    private void ChonGio(){
        Calendar calendar = Calendar.getInstance();
        int gio = calendar.get(Calendar.HOUR_OF_DAY);
        int phut = calendar.get(Calendar.MINUTE);
        TimePickerDialog timePickerDialog = new TimePickerDialog(this, new TimePickerDialog.OnTimeSetListener() {
            @Override
            public void onTimeSet(TimePicker view, int hourOfDay, int minute) {
                calendar.set(0,0,0,hourOfDay, minute);
                edtTimeReminder.setText(dinhDangGio.format(calendar.getTime()));
                gioR = hourOfDay;
                phutR = minute;
            }
        }, gio, phut, true);
        timePickerDialog.show();
    }

    private void AnhXa() {
        mDisplayDateTime = findViewById(R.id.buttonChooseTime);

        btnDone = findViewById(R.id.imageButtonDone);
        edtTitle = findViewById(R.id.edt_title);
        edtSummary = findViewById(R.id.edt_summary);
        edtDueDate = findViewById(R.id.edt_deadline);
        edtDateReminder = findViewById(R.id.edt_dateReminder);
        edtTimeReminder = findViewById(R.id.edt_timeReminder);

        btnChooseDate = findViewById(R.id.buttonChooseDate);
        btnChooseTime = findViewById(R.id.buttonChooseTime);

        btn_sound_1 = (Button)findViewById(R.id.btn_sound_1);
        btn_sound_2 = (Button)findViewById(R.id.btn_sound_2);
        btn_sound_3 = (Button)findViewById(R.id.btn_sound_3);
        btn_sound_4 = (Button)findViewById(R.id.btn_sound_4);

        mSoundManager = new SoundManager();
        mSoundManager.initSounds(getBaseContext());
        mSoundManager.addSound(1, R.raw.sound_1);
        mSoundManager.addSound(2, R.raw.sound_2);
        mSoundManager.addSound(2, R.raw.sound_3);
        mSoundManager.addSound(2, R.raw.sound_4);

    }

    void sendOnChannel1(){ //(int d, int M, int y, int h, int m) {
        String title = "You have a reminder";
        String message = "You job is " + edtTitle.getText().toString() ;

        Notification notification = new NotificationCompat.Builder(
                this, NotificationApp.CHANNEL_1_ID)
                .setSmallIcon(R.drawable.list2)
                .setContentTitle(title)
                .setContentText(message)
                .setPriority(NotificationCompat.PRIORITY_HIGH)
                .setCategory(NotificationCompat.CATEGORY_MESSAGE)
                .build();

        Log.e("Quyen", "(notificationId, notification)" + notificationId);
        int notificationId = 1;
//       NotificationManager notificationManager = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
//        notificationManager.notify(notificationId, ((NotificationCompat.Builder) notification).build());
//        notificationManager.notify(notificationId, notification);

        this.notificationManagerCompat.notify(notificationId, notification);

    }
    void DungBaoThuc(){
        alarmManager.cancel(pendingIntentBaoThuc);
        intentBaoThuc.putExtra("Bat nhac", "off");
        sendBroadcast(intentBaoThuc);
    }

}
