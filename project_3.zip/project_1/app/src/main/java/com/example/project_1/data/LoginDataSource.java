package com.example.project_1.data;

import com.example.project_1.data.model.LoggedInUser;

/**
 * Class that handles authentication w/ login credentials and retrieves user information.
 */
public class LoginDataSource {

    public LoggedInUser login(String username, String password) {
        return null;
    }

    public void logout() {
        // TODO: revoke authentication
    }
}