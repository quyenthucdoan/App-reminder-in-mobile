package com.example.project_1.data.model;

import java.io.Serializable;
import java.util.Date;

@SuppressWarnings("serial")
public class ResultTask implements Serializable {

    private String _id;
    private String title;
    private String summary;
    private String project;
    private Date timeStart;
    private Date due_date;
    private Date timeReminder;
    private int repeat_type;
    private int sound;
    private Boolean finished;

//    public ResultTask(String title, String summary, String project, Date timeStart, Date due_date, Date timeReminder, int repeat_type, Boolean finished) {
//        this.title = title;
//        this.summary = summary;
//        this.project = project;
//        this.timeStart = timeStart;
//        this.due_date = due_date;
//        this.timeReminder = timeReminder;
//        this.repeat_type = repeat_type;
//        this.finished = finished;
//    }

    public ResultTask(String _id, String title, String summary, String project, Date due_date, Date timeReminder, int sound, Boolean finished) {
        this._id = _id;
        this.title = title;
        this.summary = summary;
        this.project = project;
        this.due_date = due_date;
        this.timeReminder = timeReminder;
        this.sound = sound;
        this.finished = finished;
    }

    public ResultTask(String _id, String title, String summary, Date due_date, Date timeReminder, Boolean finished, int sound) {
        this._id = _id;
        this.title = title;
        this.summary = summary;
        this.due_date = due_date;
        this.timeReminder = timeReminder;
        this.finished = finished;
        this.sound = sound;
    }

    public String getId() {
        return _id;
    }

    public void setId(String id) {
        this._id = id;
    }

    public ResultTask(String title) {
        this.title = title;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getSummary() {
        return summary;
    }

    public void setSummary(String summary) {
        this.summary = summary;
    }

    public String getProject() {
        return project;
    }

    public void setProject(String project) {
        this.project = project;
    }

    public Date getTimeStart() {
        return timeStart;
    }

    public void setTimeStart(Date timeStart) {
        this.timeStart = timeStart;
    }

    public Date getDue_date() {
        return due_date;
    }

    public void setDue_date(Date due_date) {
        this.due_date = due_date;
    }

    public Date getTimeReminder() {
        return timeReminder;
    }

    public void setTimeReminder(Date timeReminder) {
        this.timeReminder = timeReminder;
    }

    public int getRepeat_type() {
        return repeat_type;
    }

    public void setRepeat_type(int repeat_type) {
        this.repeat_type = repeat_type;
    }

    public Boolean getFinished() {
        return finished;
    }

    public void setFinished(Boolean finished) {
        this.finished = finished;
    }
}
