package Adapter;

import android.content.Context;
import android.os.Build;
import android.text.format.DateUtils;
import android.util.Log;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.PopupMenu;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.RequiresApi;
import androidx.recyclerview.widget.RecyclerView;


import com.example.project_1.MyApplication;
import com.example.project_1.R;
import com.example.project_1.RetrofitInterface;
import com.example.project_1.data.model.Journal;
import com.squareup.picasso.Picasso;

import java.util.HashMap;
import java.util.List;


import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

public class JournalRecyclerAdapter extends RecyclerView.Adapter<JournalRecyclerAdapter.ViewHolder> {
    private Context context;
    private List<Journal> journalList;

    public JournalRecyclerAdapter(Context context, List<Journal> journalList) {
        this.context = context;
        this.journalList = journalList;
    }

    @NonNull
    @Override
    public JournalRecyclerAdapter.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context)
                .inflate(R.layout.rows, parent, false);
        return new ViewHolder(view, context);
    }
    public void setItems(List<Journal> journalList){
        this.journalList = journalList;

    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        Journal journal = journalList.get(position);
        String imageUrl = journal.getImageUrl();
        String username = journal.getUsername();

        String userId = journal.getUserId();
        String timeago = (String)DateUtils.getRelativeTimeSpanString(journal.getTimeAdded() * 1000);
        holder.title.setText(journal.getTitle());
        holder.thoughts.setText(journal.getThoughts());
        holder.timeAdded.setText(timeago);
        holder.username.setText(username);
        holder.userid = userId;
        Long timeAdded = journal.getTimeAdded();
        holder.EditDeleteButton.setOnClickListener(new View.OnClickListener() {
            @RequiresApi(api = Build.VERSION_CODES.KITKAT)
            @Override
            public void onClick(View v) {
                showMoreOptions(holder.EditDeleteButton,userId,timeAdded,holder.retrofitJournalInterface);
            }
        });
        Log.d("Binding VIewer Journal", "onBindViewHolder: " + holder);


        Picasso.get()
                .load(imageUrl)
                .placeholder(R.drawable.image_three)
                .fit()
                .into(holder.image);



    }

    @RequiresApi(api = Build.VERSION_CODES.KITKAT)
    private void showMoreOptions(ImageButton more, String userId, Long timeAdded, RetrofitInterface retrofitInterface) {
        PopupMenu popupMenu = new PopupMenu(context,more,Gravity.END);
        HashMap<String,Long> map = new HashMap<>();
        map.put("timestamp",timeAdded);
        Call<String> call = retrofitInterface.executeGetUserIdByTimeStamp(map);
        call.enqueue(new Callback<String>() {
            @Override
            public void onResponse(Call<String> call, Response<String> response) {
                if(response.code() == 200){
                    String userIdByTimeStamp = response.body();
                    if(userIdByTimeStamp.equals(userId)){
                        popupMenu.getMenu().add(Menu.NONE,0,0, "Delete");

                    }
                    popupMenu.setOnMenuItemClickListener(new PopupMenu.OnMenuItemClickListener() {
                        @Override
                        public boolean onMenuItemClick(MenuItem item) {
                            if(item.getItemId() == 0){
                                deletePostJournal(retrofitInterface, timeAdded);
                            }
                            return false;
                        }
                    });

                    popupMenu.show();
                }
            }

            @Override
            public void onFailure(Call<String> call, Throwable t) {

            }
        });
    }

    private void deletePostJournal(RetrofitInterface retrofitJournalInterface,Long timestamp) {
        HashMap<String,Long> map = new HashMap<>();
        map.put("timestamp",timestamp);
        Call<Void> call = retrofitJournalInterface.executeDeleteJournal(map);
        call.enqueue(new Callback<Void>() {
            @Override
            public void onResponse(Call<Void> call, Response<Void> response) {
                if(response.code() == 200){
//                    JournalRecyclerAdapter journalRecyclerAdapter = new JournalRecyclerAdapter()
                    
                }
            }

            @Override
            public void onFailure(Call<Void> call, Throwable t) {

            }
        });
    }

    @Override
    public int getItemCount() {
        return journalList.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {

        public TextView title,thoughts,timeAdded,username;
        public ImageView image;
        public ImageButton EditDeleteButton;
        String userid;
        private RetrofitInterface retrofitJournalInterface = MyApplication.retrofitInterface;
//        private Retrofit retrofit;
//        private String BASE_URL = "http://192.168.1.22:3000";

        public ViewHolder(@NonNull View itemView, Context context) {
            super(itemView);
            title = itemView.findViewById(R.id.journal_post_title);
            thoughts = itemView.findViewById(R.id.journal_post_description);
            image = itemView.findViewById(R.id.journal_post_imagepost);
            timeAdded = itemView.findViewById(R.id.journal_post_timeago);
            username = itemView.findViewById(R.id.journal_post_username);
            EditDeleteButton = itemView.findViewById(R.id.journal_post_more);
//            MyApplication.retrofit = new Retrofit.Builder()
//                    .baseUrl(BASE_URL)
//                    .addConverterFactory(GsonConverterFactory.create())
//                    .build();
            MyApplication.retrofitInterface = MyApplication.retrofit.create(RetrofitInterface.class);
        }


    }
}
